*[ST2]: Sublime Text 2
*[ST3]: Sublime Text 3
