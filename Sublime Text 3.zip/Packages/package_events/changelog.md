# changelog

## 1.0.1

 - Added `__version__` and `__version_info__`
 - Improved handling of built in types names in TypeError exceptions on ST2

## 1.0.0

 - Initial release
